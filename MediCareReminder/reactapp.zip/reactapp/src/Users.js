import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Users.css'

const Users = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:8080/users');
        setUsers(response.data);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <div>
      <h2>Users</h2>
      {users.length > 0 ? (
        <table border={1}>
          <thead className="users-table__header">
            <tr className="users-table__header">
              <th>ID</th>
              <th>User Name</th>
              <th>Age</th>
              <th>Address</th>
              {/* Add more table columns as needed */}
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.username}</td>
                <td>{user.age}</td>
                <td>{user.address}</td>
                {/* Render additional columns based on your user object */}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Loading users...</p>
      )}
    </div>
  );
};

export default Users;