import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Appointments = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const response = await axios.get('http://localhost:8080/appointments');
        setAppointments(response.data);
      } catch (error) {
        console.error('Error fetching appointments:', error);
      }
    };

    fetchAppointments();
  }, []);

  return (
    <div>
      <h2>Appointments</h2>
      {appointments.length > 0 ? (
        <table border={1}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Date Time</th>
              <th>Discription</th>
              {/* Add more table columns as needed */}
            </tr>
          </thead>
          <tbody>
            {appointments.map(appointment => (
              <tr key={appointment.id}>
                <td>{appointment.id}</td>
                <td>{appointment.dateTime}</td>
                <td>{appointment.description}</td>
                {/* Render additional columns based on your appointment object */}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Loading appointments...</p>
      )}
    </div>
  );
};

export default Appointments;