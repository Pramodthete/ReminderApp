import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Users.css'

const ReminderList = () => {
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    const fetchReminders = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/reminders');
        setReminders(response.data);
      } catch (error) {
        console.error('Error fetching reminders:', error);
      }
    };

    fetchReminders();
  }, []);

  return (
    <div>
      <h2>Reminder List</h2>
      {reminders.length > 0 ? (
        <table border={1}>
        <thead className="users-table__header">
          <tr className="users-table__header">
              <th>ID</th>
              <th>Title</th>
              <th>Description</th>
              {/* Add more table columns as needed */}
            </tr>
          </thead>
          <tbody>
            {reminders.map(reminder => (
              <tr key={reminder.id}>
                <td>{reminder.id}</td>
                <td>{reminder.reminderText}</td>
                <td>{reminder.username}</td>
                {/* Render additional columns based on your reminder object */}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Loading reminders...</p>
      )}
    </div>
  );
};

export default ReminderList;