import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './Home';
import ReminderList from './ReminderList';
import Users from './Users';
import Medications from './Medications';
import Appointments from './Appointments';

const App = () => {
  return (
    <Router>
      <Navbar />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/reminders" component={ReminderList} />
        <Route exact path="/users" component={Users} />
        <Route exact path="/medications" component={Medications} />
        <Route exact path="/appointments" component={Appointments} />
      </Switch>
    </Router>
  );
};

export default App;