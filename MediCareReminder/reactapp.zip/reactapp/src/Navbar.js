import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css'

const Navbar = () => {
  return (
    <nav className="navbar">
      <ul className="navbar__list">
        <li className="navbar__item">
          <NavLink exact to="/" activeClassName="active" className="navbar__link">
            Home
          </NavLink>
        </li>
        <li className="navbar__item">
          <NavLink to="/reminders" activeClassName="active" className="navbar__link">
            Reminder List
          </NavLink>
        </li>
        <li className="navbar__item">
          <NavLink to="/users" activeClassName="active" className="navbar__link">
            Users
          </NavLink>
        </li>
        <li className="navbar__item">
          <NavLink to="/medications" activeClassName="active" className="navbar__link">
            Medications
          </NavLink>
        </li>
        <li className="navbar__item">
          <NavLink to="/appointments" activeClassName="active" className="navbar__link">
            Appointments
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;