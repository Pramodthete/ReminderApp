import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Medications = () => {
  const [medications, setMedications] = useState([]);

  useEffect(() => {
    const fetchMedications = async () => {
      try {
        const response = await axios.get('http://localhost:8080/medications');
        setMedications(response.data);
      } catch (error) {
        console.error('Error fetching medications:', error);
      }
    };

    fetchMedications();
  }, []);

  return (
    <div>
      <h2>Medications</h2>
      {medications.length > 0 ? (
        <table border={1}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Medication Name</th>
              <th>Frequency</th>
              <th>Dosage</th>
              {/* Add more table columns as needed */}
            </tr>
          </thead>
          <tbody>
            {medications.map(medication => (
              <tr key={medication.id}>
                <td>{medication.id}</td>
                <td>{medication.medicationName}</td>
                <td>{medication.frequency}</td>
                <td>{medication.dosage}</td>
                {/* Render additional columns based on your medication object */}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Loading medications...</p>
      )}
    </div>
  );
};

export default Medications;